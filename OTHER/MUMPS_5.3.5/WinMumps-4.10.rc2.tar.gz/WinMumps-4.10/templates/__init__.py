import sys, os, copy

def project_id() :
  import random
  ( id, code ) = ( '', 'ABCDEFGHIJKLMNPQRSTUVWXYZ0123456789' )
  for i in [8,4,4,4,8] :
    for j in range(i) :
      id += str( code[ random.randint(0,len(code)-1) ] )
    id += '-'
  return id[:-1]


def build_file_blocks( files, mumps_install, provider ) :
  file_blocks=[]
  c_template="""\
			<File RelativePath="@RELATIVEPATH@">
			</File>
  """
  f_template="""\
		  <File RelativePath="@RELATIVEPATH@"/>
  """

  if provider == "Microsoft" : template = c_template
  elif provider == "Intel" : template = f_template
  else : template = None

  for file in files :
    file.replace( '@MUMPS_INSTALL@', mumps_install )
    if not os.path.isfile( file ) : sys.exit( "'"+file+"' is not a valid file" )
    file_blocks.append( copy.deepcopy( template ).replace( '@RELATIVEPATH@', file ) )
  return file_blocks

def build_msvc10_header_blocks( files, mumps_install, filter=False) :
  file_blocks=[]
  if filter:
    template="""
    <ClInclude Include="@RELATIVEPATH@">
      <Filter>headers</Filter>
    </ClInclude>"""
  else:
    template="""
    <ClInclude Include="@RELATIVEPATH@" />"""
  
  for file in files :
    file.replace( '@MUMPS_INSTALL@', mumps_install )
    if not os.path.isfile( file ) : sys.exit( "'"+file+"' is not a valid file" )
    file_blocks.append( copy.deepcopy( template ).replace( '@RELATIVEPATH@', file ) )
  return file_blocks

def build_msvc10_source_blocks( files, mumps_install, filter=False ) :
  file_blocks=[]
  if filter:
    template="""
    <ClCompile Include="@RELATIVEPATH@">
      <Filter>sources</Filter>
    </ClCompile>"""
  else:
    template="""
    <ClCompile Include="@RELATIVEPATH@" />"""
  for file in files :
    file.replace( '@MUMPS_INSTALL@', mumps_install )
    if not os.path.isfile( file ) : sys.exit( "'"+file+"' is not a valid file" )
    file_blocks.append( copy.deepcopy( template ).replace( '@RELATIVEPATH@', file ) )
  return file_blocks

def fill_proj( template, version, name, mumps_install, arithmetic, mpi_install, scotch, parmetis, symbols ): 
    template = template.replace( '@VERSION@', '%2.2f' %version )
    template = template.replace( '@NAME@', name )
    template = template.replace( '@PROJECTGUID@', project_id() )
    template = template.replace( '@MUMPS_INSTALL@', mumps_install )
    if arithmetic and arithmetic in [ 's','c','d','z' ] :
      template = template.replace( '@MUMPSARITH@', "MUMPS_ARITH=MUMPS_ARITH_" + arithmetic )
    else :
      template = template.replace( '@MUMPSARITH@', "" )
    if symbols :
      template = template.replace( '@SYMBOLS@', symbols )
    else:
      template = template.replace( '@SYMBOLS@', '' )
    if mpi_install == os.path.join( mumps_install, 'libseq' ) : 
      template = template.replace( '@MPI_INSTALL_INCLUDE@', mpi_install )
    else :
      template = template.replace( '@MPI_INSTALL_INCLUDE@', os.path.join( mpi_install, 'include' ) )
    if parmetis :
      template = template.replace( '@METIS@', 'parmetis' )
    else :
      template = template.replace( '@METIS@', '' )
    if scotch :
      template = template.replace( '@SCOTCH@', 'scotch' )
    else :
      template = template.replace( '@SCOTCH@', '' )
    return template

def fill_filt( template, header_blocks, source_blocks ): 
    template = template.replace( '@UNIQUEIDENTIFIER_SOURCES@', project_id() )
    template = template.replace( '@UNIQUEIDENTIFIER_HEADERS@', project_id() )
    template = template.replace( '@HEADERS@', ''.join( header_blocks ) )
    template = template.replace( '@SOURCES@', ''.join( source_blocks ) )
    return template

def write_c_project( version, name, arithmetic, headers, sources, symbols, mumps_install, winmumps_install, mpi_install, parmetis, scotch ) :
  if version<10:
    try :
      exec 'from msvc import msvc%d_template' %version
      exec 'msvc_template = msvc%d_template' %version
    except :
      sys.exit( "Visual Studio %s is not supported" %version )
    projtemplate = copy.deepcopy( msvc_template )
    projfile = os.path.join( winmumps_install, name+'.vcproj' )
    print "... writing " + projfile
    if not mumps_install or not os.path.isdir( mumps_install ) : sys.exit( "'"+mumps_install+"' is not a valid directory" )
    header_blocks = build_file_blocks( headers, mumps_install, "Microsoft" )
    source_blocks = build_file_blocks( sources, mumps_install, "Microsoft" )
    projtemplate = fill_proj( projtemplate, version, name, mumps_install, arithmetic, mpi_install, scotch, parmetis, symbols ) 
    projtemplate = fill_filt( projtemplate, header_blocks, source_blocks ) 
    projfile = open( projfile, 'w' )
    projfile.write( projtemplate )
    projfile.close()
  else:
    try :
      exec 'from msvc import msvc%d_proj_template'%version
      exec 'msvc_proj_template = msvc%d_proj_template'%version
      exec 'from msvc import msvc%d_filt_template'%version
      exec 'msvc_filt_template = msvc%d_filt_template'%version
    except Exception, exc:
      sys.exit( "Visual Studio %s is not supported (%r)"%(version,exc) )
    projtemplate = copy.deepcopy( msvc_proj_template )
    filttemplate = copy.deepcopy( msvc_filt_template )
    projfile = os.path.join( winmumps_install, name+'.vcxproj' )
    filtfile = os.path.join( winmumps_install, name+'.vcxproj.filters' )
    print "... writing %s and %s"%(projfile,filtfile)
    if not mumps_install or not os.path.isdir( mumps_install ) : sys.exit( "'"+mumps_install+"' is not a valid directory" )
    header_blocks = build_msvc10_header_blocks( headers, mumps_install )
    source_blocks = build_msvc10_source_blocks( sources, mumps_install )
    f_header_blocks = build_msvc10_header_blocks( headers, mumps_install, filter=True )
    f_source_blocks = build_msvc10_source_blocks( sources, mumps_install, filter=True )
    projtemplate = fill_proj( projtemplate, version, name, mumps_install, arithmetic, mpi_install, scotch, parmetis, symbols ) 
    projtemplate = fill_filt( projtemplate, header_blocks, source_blocks ) 
    filttemplate = fill_filt( filttemplate, f_header_blocks, f_source_blocks ) 
    projfile = open( projfile, 'w' )
    projfile.write( projtemplate )
    projfile.close()
    filtfile = open( filtfile, 'w' )
    filtfile.write( filttemplate )
    filtfile.close()
    

def write_fortran_project( version, name, arithmetic, sources, symbols, mumps_install, winmumps_install, mpi_install, parmetis, scotch ) :
  projfile = os.path.join( winmumps_install, name+'.vfproj' )
  print "... writing " + projfile
  if not mumps_install or not os.path.isdir( mumps_install ) : sys.exit( "'"+mumps_install+"' is not a valid directory" )
  source_blocks = build_file_blocks( sources, mumps_install, "Intel" )
  
  try :
    from intel import intel_template
  except :
    sys.exit( "Intel Fortran Compiler %d is not supported" %version )
  template = copy.deepcopy( intel_template )

  template = template.replace( '@VERSION@', '%2.1f'%version )
  template = template.replace( '@PROJECTGUID@', project_id() )
  template = template.replace( '@MUMPS_INSTALL@', mumps_install )
  if arithmetic and arithmetic in [ 's','c','d','z' ] :
    template = template.replace( '@MUMPSARITH@', "MUMPS_ARITH=MUMPS_ARITH_" + arithmetic )
  else :
    template = template.replace( '@MUMPSARITH@', "" )
  if symbols :
    template = template.replace( '@SYMBOLS@', symbols )
  else:
    template = template.replace( '@SYMBOLS@', '' )
  if mpi_install == os.path.join( mumps_install, 'libseq' ) : 
    template = template.replace( '@MPI_INSTALL_INCLUDE@', mpi_install )
  else :
    template = template.replace( '@MPI_INSTALL_INCLUDE@', os.path.join( mpi_install, 'include' ) )
  if parmetis :
    template = template.replace( '@METIS@', 'parmetis' )
  else :
    template = template.replace( '@METIS@', '' )
  if scotch :
    template = template.replace( '@SCOTCH@', 'scotch' )
  else :
    template = template.replace( '@SCOTCH@', '' )
  template = template.replace( '@SOURCES@', ''.join( source_blocks ) )
  projfile = open( projfile, 'w' )
  projfile.write( template )
  projfile.close()
