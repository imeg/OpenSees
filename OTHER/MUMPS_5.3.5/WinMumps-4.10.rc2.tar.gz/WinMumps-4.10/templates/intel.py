intel_template ="""\
<?xml version="1.0" encoding="UTF-8"?>
<VisualStudioProject ProjectType="typeStaticLibrary" ProjectCreator="Intel Fortran" Keyword="Static Library" Version="@VERSION@" ProjectIdGuid="{@PROJECTGUID@}">
	<Platforms>
		<Platform Name="Win32"/>
		<Platform Name="x64"/>
	</Platforms>
	<Configurations>
		<Configuration Name="Debug|Win32" OutputDirectory="@MUMPS_INSTALL@/lib/$(ConfigurationName)/$(PlatformName)" IntermediateDirectory="./do/$(ProjectName)/$(ConfigurationName)/$(PlatformName)" DeleteExtensionsOnClean="*.obj;*.mod;*.pdb;*.asm;*.map;*.dyn;*.dpi;*.tmp;*.log;*.lib;$(TargetPath)" ConfigurationType="typeStaticLibrary">
				<Tool Name="VFMidlTool" SuppressStartupBanner="true" TypeLibraryName="$(IntDir)/$(InputName).tlb"/>
				<Tool Name="VFPreBuildEventTool" CommandLine="time /t"/>
				<Tool Name="VFFortranCompilerTool" SuppressStartupBanner="true" DebugInformationFormat="debugEnabled" Optimization="optimizeDisabled" OptimizeForProcessor="procOptimizePentiumProThruIII" Preprocess="preprocessYes" AdditionalIncludeDirectories="@MUMPS_INSTALL@\include;@MUMPS_INSTALL@\src;@MPI_INSTALL_INCLUDE@" PreprocessorDefinitions="@METIS@;@SCOTCH@;pord;@SYMBOLS@" EnableRecursion="true" SuppressUsageMessages="true" ExternalNameInterpretation="extNameUpperCase" ModulePath="$(INTDIR)/" ObjectFile="$(INTDIR)/" RuntimeLibrary="rtMultiThreadedDebugDLL" CompileOnly="true"/>
				<Tool Name="VFPostBuildEventTool" CommandLine="time /t"/>
				<Tool Name="VFCustomBuildTool"/>
				<Tool Name="VFResourceCompilerTool" ResourceOutputFileName="$(IntDir)/$(InputName).res"/>
				<Tool Name="VFPreLinkEventTool" CommandLine="time /t"/>
				<Tool Name="VFLibrarianTool" OutputFile="$(OutDir)/$(ProjectName).lib" SuppressStartupBanner="true"/></Configuration>
		<Configuration Name="Release|Win32" OutputDirectory="@MUMPS_INSTALL@/lib/$(ConfigurationName)/$(PlatformName)" IntermediateDirectory="./do/$(ProjectName)/$(ConfigurationName)/$(PlatformName)" DeleteExtensionsOnClean="*.obj;*.mod;*.pdb;*.asm;*.map;*.dyn;*.dpi;*.tmp;*.log;*.lib;$(TargetPath)" ConfigurationType="typeStaticLibrary">
				<Tool Name="VFMidlTool" SuppressStartupBanner="true" TypeLibraryName="$(IntDir)/$(InputName).tlb"/>
				<Tool Name="VFPreBuildEventTool" CommandLine="time /t"/>
				<Tool Name="VFFortranCompilerTool" SuppressStartupBanner="true" Optimization="optimizeFull" InlineFunctionExpansion="expandAnySuitable" OptimizeForProcessor="procOptimizePentiumProThruIII" Preprocess="preprocessYes" AdditionalIncludeDirectories="@MUMPS_INSTALL@\include;@MUMPS_INSTALL@\src;@MPI_INSTALL_INCLUDE@" PreprocessorDefinitions="@METIS@;@SCOTCH@;pord;@SYMBOLS@" EnableRecursion="true" ExternalNameInterpretation="extNameUpperCase" ModulePath="$(INTDIR)/" ObjectFile="$(INTDIR)/" RuntimeLibrary="rtMultiThreadedDLL" CompileOnly="true"/>
				<Tool Name="VFPostBuildEventTool" CommandLine="time /t"/>
				<Tool Name="VFCustomBuildTool"/>
				<Tool Name="VFResourceCompilerTool" ResourceOutputFileName="$(IntDir)/$(InputName).res"/>
				<Tool Name="VFPreLinkEventTool" CommandLine="time /t"/>
				<Tool Name="VFLibrarianTool" OutputFile="$(OutDir)/$(ProjectName).lib" SuppressStartupBanner="true"/></Configuration>
		<Configuration Name="Profile|Win32" OutputDirectory="@MUMPS_INSTALL@/lib/$(ConfigurationName)/$(PlatformName)" IntermediateDirectory="./do/$(ProjectName)/$(ConfigurationName)/$(PlatformName)" DeleteExtensionsOnClean="*.obj;*.mod;*.pdb;*.asm;*.map;*.dyn;*.dpi;*.tmp;*.log;*.lib;$(TargetPath)" ConfigurationType="typeStaticLibrary" MustRebuild="true">
				<Tool Name="VFMidlTool" SuppressStartupBanner="true" TypeLibraryName="$(IntDir)/$(InputName).tlb"/>
				<Tool Name="VFPreBuildEventTool" CommandLine="time /t"/>
				<Tool Name="VFPostBuildEventTool" CommandLine="time /t"/>
				<Tool Name="VFFortranCompilerTool" SwitchesHaveChanged="true" SuppressStartupBanner="true" Optimization="optimizeFull" InlineFunctionExpansion="expandAnySuitable" OptimizeForProcessor="procOptimizePentiumProThruIII" Preprocess="preprocessYes" AdditionalIncludeDirectories="@MUMPS_INSTALL@\include;@MUMPS_INSTALL@\src;@MPI_INSTALL_INCLUDE@" PreprocessorDefinitions="@METIS@;@SCOTCH@;pord;@SYMBOLS@" EnableRecursion="true" ExternalNameInterpretation="extNameUpperCase" ModulePath="$(INTDIR)/" ObjectFile="$(INTDIR)/" RuntimeLibrary="rtMultiThreadedDLL" CompileOnly="true"/>
				<Tool Name="VFCustomBuildTool"/>
				<Tool Name="VFLibrarianTool" MustRebuild="true" OutputFile="$(OutDir)/$(ProjectName).lib" SuppressStartupBanner="true"/>
				<Tool Name="VFPreLinkEventTool" CommandLine="time /t"/>
				<Tool Name="VFResourceCompilerTool" ResourceOutputFileName="$(IntDir)/$(InputName).res"/></Configuration>
		<Configuration Name="Debug|x64" OutputDirectory="@MUMPS_INSTALL@/lib/$(ConfigurationName)/$(PlatformName)" IntermediateDirectory="./do/$(ProjectName)/$(ConfigurationName)/$(PlatformName)" DeleteExtensionsOnClean="*.obj;*.mod;*.pdb;*.asm;*.map;*.dyn;*.dpi;*.tmp;*.log;*.lib;$(TargetPath)" ConfigurationType="typeStaticLibrary" MustRebuild="true">
				<Tool Name="VFMidlTool" SuppressStartupBanner="true" TypeLibraryName="$(IntDir)/$(InputName).tlb"/>
				<Tool Name="VFPreBuildEventTool" CommandLine="time /t"/>
				<Tool Name="VFPostBuildEventTool" CommandLine="time /t"/>
				<Tool Name="VFFortranCompilerTool" SwitchesHaveChanged="true" SuppressStartupBanner="true" DebugInformationFormat="debugEnabled" Optimization="optimizeDisabled" Preprocess="preprocessYes" AdditionalIncludeDirectories="@MUMPS_INSTALL@\include;@MUMPS_INSTALL@\src;@MPI_INSTALL_INCLUDE@" EnableRecursion="true" WarnTruncateSource="true" ExternalNameInterpretation="extNameUpperCase" ModulePath="$(INTDIR)/" ObjectFile="$(INTDIR)/" RuntimeLibrary="rtMultiThreadedDebugDLL" CompileOnly="true"/>
				<Tool Name="VFCustomBuildTool"/>
				<Tool Name="VFLibrarianTool" OutputFile="$(OutDir)/$(ProjectName).lib" SuppressStartupBanner="true"/>
				<Tool Name="VFPreLinkEventTool" CommandLine="time /t"/>
				<Tool Name="VFResourceCompilerTool" ResourceOutputFileName="$(IntDir)/$(InputName).res"/></Configuration>
		<Configuration Name="Release|x64" OutputDirectory="@MUMPS_INSTALL@/lib/$(ConfigurationName)/$(PlatformName)" IntermediateDirectory="./do/$(ProjectName)/$(ConfigurationName)/$(PlatformName)" DeleteExtensionsOnClean="*.obj;*.mod;*.pdb;*.asm;*.map;*.dyn;*.dpi;*.tmp;*.log;*.lib;$(TargetPath)" ConfigurationType="typeStaticLibrary">
				<Tool Name="VFMidlTool" SuppressStartupBanner="true" TypeLibraryName="$(IntDir)/$(InputName).tlb"/>
				<Tool Name="VFPreBuildEventTool" CommandLine="time /t"/>
				<Tool Name="VFPostBuildEventTool" CommandLine="time /t"/>
				<Tool Name="VFFortranCompilerTool" SuppressStartupBanner="true" Optimization="optimizeFull" InlineFunctionExpansion="expandAnySuitable" Preprocess="preprocessYes" AdditionalIncludeDirectories="@MUMPS_INSTALL@\include;@MUMPS_INSTALL@\src;@MPI_INSTALL_INCLUDE@" PreprocessorDefinitions="@METIS@;@SCOTCH@;pord;@SYMBOLS@" EnableRecursion="true" ExternalNameInterpretation="extNameUpperCase" ModulePath="$(INTDIR)/" ObjectFile="$(INTDIR)/" RuntimeLibrary="rtMultiThreadedDLL" CompileOnly="true"/>
				<Tool Name="VFCustomBuildTool"/>
				<Tool Name="VFLibrarianTool" OutputFile="$(OutDir)/$(ProjectName).lib" SuppressStartupBanner="true"/>
				<Tool Name="VFPreLinkEventTool" CommandLine="time /t"/>
				<Tool Name="VFResourceCompilerTool" ResourceOutputFileName="$(IntDir)/$(InputName).res"/></Configuration>
		<Configuration Name="Profile|x64" OutputDirectory="@MUMPS_INSTALL@/lib/$(ConfigurationName)/$(PlatformName)" IntermediateDirectory="./do/$(ProjectName)/$(ConfigurationName)/$(PlatformName)" DeleteExtensionsOnClean="*.obj;*.mod;*.pdb;*.asm;*.map;*.dyn;*.dpi;*.tmp;*.log;*.lib;$(TargetPath)" ConfigurationType="typeStaticLibrary" MustRebuild="true">
				<Tool Name="VFMidlTool" SwitchesHaveChanged="true" SuppressStartupBanner="true" TypeLibraryName="$(IntDir)/$(InputName).tlb"/>
				<Tool Name="VFPreBuildEventTool" CommandLine="time /t"/>
				<Tool Name="VFFortranCompilerTool" SwitchesHaveChanged="true" SuppressStartupBanner="true" Optimization="optimizeFull" InlineFunctionExpansion="expandAnySuitable" Preprocess="preprocessYes" AdditionalIncludeDirectories="@MUMPS_INSTALL@\include;@MUMPS_INSTALL@\src;@MPI_INSTALL_INCLUDE@" EnableRecursion="true" ExternalNameInterpretation="extNameUpperCase" ModulePath="$(INTDIR)/" ObjectFile="$(INTDIR)/" RuntimeLibrary="rtMultiThreadedDLL" CompileOnly="true"/>
				<Tool Name="VFPostBuildEventTool" CommandLine="time /t"/>
				<Tool Name="VFCustomBuildTool"/>
				<Tool Name="VFResourceCompilerTool" SwitchesHaveChanged="true" ResourceOutputFileName="$(IntDir)/$(InputName).res"/>
				<Tool Name="VFPreLinkEventTool" CommandLine="time /t"/>
				<Tool Name="VFLibrarianTool" SwitchesHaveChanged="true" MustRebuild="true" OutputFile="$(OutDir)/$(ProjectName).lib" SuppressStartupBanner="true"/></Configuration></Configurations>
	<Files>
		<Filter Name="sources" Filter="f90;f;f77;F;F90">
		@SOURCES@
		</Filter>
	</Files>
	<Globals/>
</VisualStudioProject>
"""

