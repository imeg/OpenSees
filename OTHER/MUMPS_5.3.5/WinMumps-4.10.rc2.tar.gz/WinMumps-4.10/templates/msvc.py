msvc10_filt_template='''\
<?xml version="1.0" encoding="utf-8"?>
<Project ToolsVersion="4.0" xmlns="http://schemas.microsoft.com/developer/msbuild/2003">
  <ItemGroup>
    <Filter Include="sources">
      <UniqueIdentifier>{@UNIQUEIDENTIFIER_SOURCES@}</UniqueIdentifier>
      <Extensions>cpp;c;cc;cxx</Extensions>
    </Filter>
    <Filter Include="headers">
      <UniqueIdentifier>{@UNIQUEIDENTIFIER_HEADERS@}</UniqueIdentifier>
      <Extensions>h;hpp;hxx</Extensions>
    </Filter>
  </ItemGroup>
  <ItemGroup>@SOURCES@
  </ItemGroup>
  <ItemGroup>@HEADERS@
  </ItemGroup>
</Project>
'''


msvc10_proj_template='''\
<?xml version="1.0" encoding="utf-8"?>
<Project DefaultTargets="Build" ToolsVersion="4.0" xmlns="http://schemas.microsoft.com/developer/msbuild/2003">
  <ItemGroup Label="ProjectConfigurations">
    <ProjectConfiguration Include="Debug|Win32">
      <Configuration>Debug</Configuration>
      <Platform>Win32</Platform>
    </ProjectConfiguration>
    <ProjectConfiguration Include="Debug|x64">
      <Configuration>Debug</Configuration>
      <Platform>x64</Platform>
    </ProjectConfiguration>
    <ProjectConfiguration Include="Profile|Win32">
      <Configuration>Profile</Configuration>
      <Platform>Win32</Platform>
    </ProjectConfiguration>
    <ProjectConfiguration Include="Profile|x64">
      <Configuration>Profile</Configuration>
      <Platform>x64</Platform>
    </ProjectConfiguration>
    <ProjectConfiguration Include="Release|Win32">
      <Configuration>Release</Configuration>
      <Platform>Win32</Platform>
    </ProjectConfiguration>
    <ProjectConfiguration Include="Release|x64">
      <Configuration>Release</Configuration>
      <Platform>x64</Platform>
    </ProjectConfiguration>
  </ItemGroup>
  <PropertyGroup Label="Globals">
    <ProjectGuid>{@PROJECTGUID@}</ProjectGuid>
    <RootNamespace>@NAME@_rootnamespace</RootNamespace>
    <Keyword>Win32Proj</Keyword>
  </PropertyGroup>
  <Import Project="$(VCTargetsPath)\Microsoft.Cpp.Default.props" />
  <PropertyGroup Condition="'$(Configuration)|$(Platform)'=='Profile|Win32'" Label="Configuration">
    <ConfigurationType>StaticLibrary</ConfigurationType>
    <CharacterSet>MultiByte</CharacterSet>
    <WholeProgramOptimization>false</WholeProgramOptimization>
  </PropertyGroup>
  <PropertyGroup Condition="'$(Configuration)|$(Platform)'=='Release|Win32'" Label="Configuration">
    <ConfigurationType>StaticLibrary</ConfigurationType>
    <CharacterSet>MultiByte</CharacterSet>
    <WholeProgramOptimization>false</WholeProgramOptimization>
  </PropertyGroup>
  <PropertyGroup Condition="'$(Configuration)|$(Platform)'=='Debug|Win32'" Label="Configuration">
    <ConfigurationType>StaticLibrary</ConfigurationType>
    <CharacterSet>MultiByte</CharacterSet>
    <WholeProgramOptimization>false</WholeProgramOptimization>
  </PropertyGroup>
  <PropertyGroup Condition="'$(Configuration)|$(Platform)'=='Profile|x64'" Label="Configuration">
    <ConfigurationType>StaticLibrary</ConfigurationType>
    <UseOfMfc>false</UseOfMfc>
    <CharacterSet>MultiByte</CharacterSet>
    <WholeProgramOptimization>false</WholeProgramOptimization>
  </PropertyGroup>
  <PropertyGroup Condition="'$(Configuration)|$(Platform)'=='Release|x64'" Label="Configuration">
    <ConfigurationType>StaticLibrary</ConfigurationType>
    <UseOfMfc>false</UseOfMfc>
    <CharacterSet>MultiByte</CharacterSet>
    <WholeProgramOptimization>false</WholeProgramOptimization>
  </PropertyGroup>
  <PropertyGroup Condition="'$(Configuration)|$(Platform)'=='Debug|x64'" Label="Configuration">
    <ConfigurationType>StaticLibrary</ConfigurationType>
    <UseOfMfc>false</UseOfMfc>
    <CharacterSet>MultiByte</CharacterSet>
    <WholeProgramOptimization>false</WholeProgramOptimization>
  </PropertyGroup>
  <Import Project="$(VCTargetsPath)\Microsoft.Cpp.props" />
  <ImportGroup Label="ExtensionSettings">
  </ImportGroup>
  <ImportGroup Condition="'$(Configuration)|$(Platform)'=='Profile|Win32'" Label="PropertySheets">
    <Import Project="$(UserRootDir)\Microsoft.Cpp.$(Platform).user.props" Condition="exists('$(UserRootDir)\Microsoft.Cpp.$(Platform).user.props')" Label="LocalAppDataPlatform" />
  </ImportGroup>
  <ImportGroup Condition="'$(Configuration)|$(Platform)'=='Release|Win32'" Label="PropertySheets">
    <Import Project="$(UserRootDir)\Microsoft.Cpp.$(Platform).user.props" Condition="exists('$(UserRootDir)\Microsoft.Cpp.$(Platform).user.props')" Label="LocalAppDataPlatform" />
  </ImportGroup>
  <ImportGroup Condition="'$(Configuration)|$(Platform)'=='Debug|Win32'" Label="PropertySheets">
    <Import Project="$(UserRootDir)\Microsoft.Cpp.$(Platform).user.props" Condition="exists('$(UserRootDir)\Microsoft.Cpp.$(Platform).user.props')" Label="LocalAppDataPlatform" />
  </ImportGroup>
  <ImportGroup Condition="'$(Configuration)|$(Platform)'=='Profile|x64'" Label="PropertySheets">
    <Import Project="$(UserRootDir)\Microsoft.Cpp.$(Platform).user.props" Condition="exists('$(UserRootDir)\Microsoft.Cpp.$(Platform).user.props')" Label="LocalAppDataPlatform" />
  </ImportGroup>
  <ImportGroup Condition="'$(Configuration)|$(Platform)'=='Release|x64'" Label="PropertySheets">
    <Import Project="$(UserRootDir)\Microsoft.Cpp.$(Platform).user.props" Condition="exists('$(UserRootDir)\Microsoft.Cpp.$(Platform).user.props')" Label="LocalAppDataPlatform" />
  </ImportGroup>
  <ImportGroup Condition="'$(Configuration)|$(Platform)'=='Debug|x64'" Label="PropertySheets">
    <Import Project="$(UserRootDir)\Microsoft.Cpp.$(Platform).user.props" Condition="exists('$(UserRootDir)\Microsoft.Cpp.$(Platform).user.props')" Label="LocalAppDataPlatform" />
  </ImportGroup>
  <PropertyGroup Label="UserMacros" />
  <PropertyGroup>
    <_ProjectFileVersion>10.0.40219.1</_ProjectFileVersion>
    <OutDir Condition="'$(Configuration)|$(Platform)'=='Debug|Win32'">@MUMPS_INSTALL@/lib/$(Configuration)/$(Platform)\</OutDir>
    <IntDir Condition="'$(Configuration)|$(Platform)'=='Debug|Win32'">./do/$(ProjectName)/$(Configuration)/$(Platform)\</IntDir>
    <OutDir Condition="'$(Configuration)|$(Platform)'=='Debug|x64'">@MUMPS_INSTALL@/lib/$(Configuration)/$(Platform)\</OutDir>
    <IntDir Condition="'$(Configuration)|$(Platform)'=='Debug|x64'">./do/$(ProjectName)/$(Configuration)/$(Platform)\</IntDir>
    <OutDir Condition="'$(Configuration)|$(Platform)'=='Release|Win32'">@MUMPS_INSTALL@/lib/$(Configuration)/$(Platform)\</OutDir>
    <IntDir Condition="'$(Configuration)|$(Platform)'=='Release|Win32'">./do/$(ProjectName)/$(Configuration)/$(Platform)\</IntDir>
    <OutDir Condition="'$(Configuration)|$(Platform)'=='Release|x64'">@MUMPS_INSTALL@/lib/$(Configuration)/$(Platform)\</OutDir>
    <IntDir Condition="'$(Configuration)|$(Platform)'=='Release|x64'">./do/$(ProjectName)/$(Configuration)/$(Platform)\</IntDir>
    <OutDir Condition="'$(Configuration)|$(Platform)'=='Profile|Win32'">@MUMPS_INSTALL@/lib/$(Configuration)/$(Platform)\</OutDir>
    <IntDir Condition="'$(Configuration)|$(Platform)'=='Profile|Win32'">./do/$(ProjectName)/$(Configuration)/$(Platform)\</IntDir>
    <OutDir Condition="'$(Configuration)|$(Platform)'=='Profile|x64'">@MUMPS_INSTALL@/lib/$(Configuration)/$(Platform)\</OutDir>
    <IntDir Condition="'$(Configuration)|$(Platform)'=='Profile|x64'">./do/$(ProjectName)/$(Configuration)/$(Platform)\</IntDir>
  </PropertyGroup>
  <ItemDefinitionGroup Condition="'$(Configuration)|$(Platform)'=='Debug|Win32'">
    <PreBuildEvent>
      <Command>time /t</Command>
    </PreBuildEvent>
    <ClCompile>
      <Optimization>Disabled</Optimization>
      <AdditionalIncludeDirectories>@MUMPS_INSTALL@\include;@MUMPS_INSTALL@\PORD\include;@MPI_INSTALL_INCLUDE@;%(AdditionalIncludeDirectories)</AdditionalIncludeDirectories>
      <PreprocessorDefinitions>WIN32;_DEBUG;_LIB;UPPER;MUMPS_CALL=;UpCase;@METIS@;@SCOTCH@;pord;NOMINMAX;@MUMPSARITH@;@SYMBOLS@;%(PreprocessorDefinitions)</PreprocessorDefinitions>
      <MinimalRebuild>false</MinimalRebuild>
      <BasicRuntimeChecks>Default</BasicRuntimeChecks>
      <SmallerTypeCheck>true</SmallerTypeCheck>
      <RuntimeLibrary>MultiThreadedDebugDLL</RuntimeLibrary>
      <DisableLanguageExtensions>false</DisableLanguageExtensions>
      <PrecompiledHeader>
      </PrecompiledHeader>
      <WarningLevel>Level2</WarningLevel>
      <DebugInformationFormat>EditAndContinue</DebugInformationFormat>
      <CompileAs>CompileAsC</CompileAs>
    </ClCompile>
    <PreLinkEvent>
      <Command>time /t</Command>
    </PreLinkEvent>
    <PostBuildEvent>
      <Command>time /t</Command>
    </PostBuildEvent>
  </ItemDefinitionGroup>
  <ItemDefinitionGroup Condition="'$(Configuration)|$(Platform)'=='Debug|x64'">
    <PreBuildEvent>
      <Command>time /t</Command>
    </PreBuildEvent>
    <Midl>
      <TargetEnvironment>X64</TargetEnvironment>
    </Midl>
    <ClCompile>
      <Optimization>Disabled</Optimization>
      <AdditionalIncludeDirectories>@MUMPS_INSTALL@\include;@MUMPS_INSTALL@\PORD\include;@MPI_INSTALL_INCLUDE@;%(AdditionalIncludeDirectories)</AdditionalIncludeDirectories>
      <PreprocessorDefinitions>WIN64;_DEBUG;_LIB;UPPER;MUMPS_CALL=;UpCase;@METIS@;@SCOTCH@;pord;NOMINMAX;@MUMPSARITH@;@SYMBOLS@;%(PreprocessorDefinitions)</PreprocessorDefinitions>
      <MinimalRebuild>false</MinimalRebuild>
      <BasicRuntimeChecks>Default</BasicRuntimeChecks>
      <SmallerTypeCheck>true</SmallerTypeCheck>
      <RuntimeLibrary>MultiThreadedDebugDLL</RuntimeLibrary>
      <PrecompiledHeader>
      </PrecompiledHeader>
      <WarningLevel>Level2</WarningLevel>
      <DebugInformationFormat>EditAndContinue</DebugInformationFormat>
    </ClCompile>
    <PreLinkEvent>
      <Command>time /t</Command>
    </PreLinkEvent>
    <PostBuildEvent>
      <Command>time /t</Command>
    </PostBuildEvent>
  </ItemDefinitionGroup>
  <ItemDefinitionGroup Condition="'$(Configuration)|$(Platform)'=='Release|Win32'">
    <PreBuildEvent>
      <Command>time /t</Command>
    </PreBuildEvent>
    <ClCompile>
      <Optimization>Full</Optimization>
      <InlineFunctionExpansion>AnySuitable</InlineFunctionExpansion>
      <IntrinsicFunctions>true</IntrinsicFunctions>
      <FavorSizeOrSpeed>Speed</FavorSizeOrSpeed>
      <OmitFramePointers>true</OmitFramePointers>
      <WholeProgramOptimization>false</WholeProgramOptimization>
      <AdditionalIncludeDirectories>@MUMPS_INSTALL@\include;@MUMPS_INSTALL@\PORD\include;@MPI_INSTALL_INCLUDE@;%(AdditionalIncludeDirectories)</AdditionalIncludeDirectories>
      <PreprocessorDefinitions>WIN32;NDEBUG;_LIB;UPPER;MUMPS_CALL=;UpCase;@METIS@;@SCOTCH@;pord;NOMINMAX;@MUMPSARITH@;@SYMBOLS@;%(PreprocessorDefinitions)</PreprocessorDefinitions>
      <RuntimeLibrary>MultiThreadedDLL</RuntimeLibrary>
      <StructMemberAlignment>Default</StructMemberAlignment>
      <DisableLanguageExtensions>false</DisableLanguageExtensions>
      <PrecompiledHeader>
      </PrecompiledHeader>
      <WarningLevel>Level2</WarningLevel>
      <DebugInformationFormat>
      </DebugInformationFormat>
      <CompileAs>CompileAsC</CompileAs>
    </ClCompile>
    <PreLinkEvent>
      <Command>time /t</Command>
    </PreLinkEvent>
    <PostBuildEvent>
      <Command>time /t</Command>
    </PostBuildEvent>
  </ItemDefinitionGroup>
  <ItemDefinitionGroup Condition="'$(Configuration)|$(Platform)'=='Release|x64'">
    <PreBuildEvent>
      <Command>time /t</Command>
    </PreBuildEvent>
    <Midl>
      <TargetEnvironment>X64</TargetEnvironment>
    </Midl>
    <ClCompile>
      <Optimization>Full</Optimization>
      <InlineFunctionExpansion>AnySuitable</InlineFunctionExpansion>
      <IntrinsicFunctions>true</IntrinsicFunctions>
      <FavorSizeOrSpeed>Speed</FavorSizeOrSpeed>
      <OmitFramePointers>true</OmitFramePointers>
      <AdditionalIncludeDirectories>@MUMPS_INSTALL@\include;@MUMPS_INSTALL@\PORD\include;@MPI_INSTALL_INCLUDE@;%(AdditionalIncludeDirectories)</AdditionalIncludeDirectories>
      <PreprocessorDefinitions>WIN64;NDEBUG;_LIB;UPPER;MUMPS_CALL=;UpCase;@METIS@;@SCOTCH@;pord;NOMINMAX;@MUMPSARITH@;@SYMBOLS@;%(PreprocessorDefinitions)</PreprocessorDefinitions>
      <RuntimeLibrary>MultiThreadedDLL</RuntimeLibrary>
      <StructMemberAlignment>Default</StructMemberAlignment>
      <PrecompiledHeader>
      </PrecompiledHeader>
      <WarningLevel>Level2</WarningLevel>
      <DebugInformationFormat>
      </DebugInformationFormat>
    </ClCompile>
    <PreLinkEvent>
      <Command>time /t</Command>
    </PreLinkEvent>
    <PostBuildEvent>
      <Command>time /t</Command>
    </PostBuildEvent>
  </ItemDefinitionGroup>
  <ItemDefinitionGroup Condition="'$(Configuration)|$(Platform)'=='Profile|Win32'">
    <PreBuildEvent>
      <Command>time /t</Command>
    </PreBuildEvent>
    <ClCompile>
      <Optimization>Full</Optimization>
      <InlineFunctionExpansion>AnySuitable</InlineFunctionExpansion>
      <IntrinsicFunctions>true</IntrinsicFunctions>
      <FavorSizeOrSpeed>Speed</FavorSizeOrSpeed>
      <OmitFramePointers>true</OmitFramePointers>
      <AdditionalIncludeDirectories>@MUMPS_INSTALL@\include;@MUMPS_INSTALL@\PORD\include;@MPI_INSTALL_INCLUDE@;%(AdditionalIncludeDirectories)</AdditionalIncludeDirectories>
      <PreprocessorDefinitions>WIN32;NDEBUG;_LIB;UPPER;MUMPS_CALL=;UpCase;@METIS@;@SCOTCH@;pord;NOMINMAX;@MUMPSARITH@;@SYMBOLS@;%(PreprocessorDefinitions)</PreprocessorDefinitions>
      <RuntimeLibrary>MultiThreadedDLL</RuntimeLibrary>
      <StructMemberAlignment>Default</StructMemberAlignment>
      <DisableLanguageExtensions>false</DisableLanguageExtensions>
      <PrecompiledHeader>
      </PrecompiledHeader>
      <WarningLevel>Level2</WarningLevel>
      <DebugInformationFormat>ProgramDatabase</DebugInformationFormat>
      <CompileAs>CompileAsC</CompileAs>
    </ClCompile>
    <PreLinkEvent>
      <Command>time /t</Command>
    </PreLinkEvent>
    <PostBuildEvent>
      <Command>time /t</Command>
    </PostBuildEvent>
  </ItemDefinitionGroup>
  <ItemDefinitionGroup Condition="'$(Configuration)|$(Platform)'=='Profile|x64'">
    <PreBuildEvent>
      <Command>time /t</Command>
    </PreBuildEvent>
    <Midl>
      <TargetEnvironment>X64</TargetEnvironment>
    </Midl>
    <ClCompile>
      <Optimization>Full</Optimization>
      <InlineFunctionExpansion>AnySuitable</InlineFunctionExpansion>
      <IntrinsicFunctions>true</IntrinsicFunctions>
      <FavorSizeOrSpeed>Speed</FavorSizeOrSpeed>
      <OmitFramePointers>true</OmitFramePointers>
      <AdditionalIncludeDirectories>@MUMPS_INSTALL@\include;@MUMPS_INSTALL@\PORD\include;@MPI_INSTALL_INCLUDE@;%(AdditionalIncludeDirectories)</AdditionalIncludeDirectories>
      <PreprocessorDefinitions>WIN64;NDEBUG;_LIB;UPPER;MUMPS_CALL=;UpCase;@METIS@;@SCOTCH@;pord;NOMINMAX;@MUMPSARITH@;@SYMBOLS@;%(PreprocessorDefinitions)</PreprocessorDefinitions>
      <RuntimeLibrary>MultiThreadedDLL</RuntimeLibrary>
      <StructMemberAlignment>Default</StructMemberAlignment>
      <PrecompiledHeader>
      </PrecompiledHeader>
      <WarningLevel>Level2</WarningLevel>
      <DebugInformationFormat>ProgramDatabase</DebugInformationFormat>
    </ClCompile>
    <PreLinkEvent>
      <Command>time /t</Command>
    </PreLinkEvent>
    <PostBuildEvent>
      <Command>time /t</Command>
    </PostBuildEvent>
  </ItemDefinitionGroup>
  <ItemGroup>@SOURCES@
  </ItemGroup>
  <ItemGroup>@HEADERS@
  </ItemGroup>
  <Import Project="$(VCTargetsPath)\Microsoft.Cpp.targets" />
  <ImportGroup Label="ExtensionTargets">
  </ImportGroup>
</Project>
'''

msvc8_template ="""\
<?xml version="1.0" encoding="Windows-1252"?>
<VisualStudioProject
	ProjectType="Visual C++"
	Version="@VERSION@"
	Name="@NAME@"
	ProjectGUID="{@PROJECTGUID@}"
	RootNamespace="@NAME@_rootnamespace"
	Keyword="Win32Proj"
	>
	<Platforms>
		<Platform
			Name="Win32"
		/>
		<Platform
			Name="x64"
		/>
	</Platforms>
	<ToolFiles>
	</ToolFiles>
	<Configurations>
		<Configuration
			Name="Debug|Win32"
			OutputDirectory="@MUMPS_INSTALL@/lib/$(ConfigurationName)/$(PlatformName)"
			IntermediateDirectory="./do/$(ProjectName)/$(ConfigurationName)/$(PlatformName)"
			ConfigurationType="4"
			CharacterSet="2"
			WholeProgramOptimization="0"
			>
			<Tool
				Name="VCPreBuildEventTool"
				CommandLine="time /t"
			/>
			<Tool
				Name="VCCustomBuildTool"
			/>
			<Tool
				Name="VCXMLDataGeneratorTool"
			/>
			<Tool
				Name="VCWebServiceProxyGeneratorTool"
			/>
			<Tool
				Name="VCMIDLTool"
			/>
			<Tool
				Name="VCCLCompilerTool"
				Optimization="0"
				AdditionalIncludeDirectories="@MUMPS_INSTALL@\include;@MUMPS_INSTALL@\PORD\include;@MPI_INSTALL_INCLUDE@"
				PreprocessorDefinitions="WIN32;_DEBUG;_LIB;UPPER;MUMPS_CALL=;UpCase;@METIS@;@SCOTCH@;pord;NOMINMAX;@MUMPSARITH@;@SYMBOLS@"
				MinimalRebuild="false"
				BasicRuntimeChecks="0"
				SmallerTypeCheck="true"
				RuntimeLibrary="3"
				DisableLanguageExtensions="false"
				UsePrecompiledHeader="0"
				WarningLevel="2"
				Detect64BitPortabilityProblems="true"
				DebugInformationFormat="4"
				CompileAs="1"
			/>
			<Tool
				Name="VCManagedResourceCompilerTool"
			/>
			<Tool
				Name="VCResourceCompilerTool"
			/>
			<Tool
				Name="VCPreLinkEventTool"
				CommandLine="time /t"
			/>
			<Tool
				Name="VCLibrarianTool"
			/>
			<Tool
				Name="VCALinkTool"
			/>
			<Tool
				Name="VCXDCMakeTool"
			/>
			<Tool
				Name="VCBscMakeTool"
			/>
			<Tool
				Name="VCFxCopTool"
			/>
			<Tool
				Name="VCPostBuildEventTool"
				CommandLine="time /t"
			/>
		</Configuration>
		<Configuration
			Name="Debug|x64"
			OutputDirectory="@MUMPS_INSTALL@/lib/$(ConfigurationName)/$(PlatformName)"
			IntermediateDirectory="./do/$(ProjectName)/$(ConfigurationName)/$(PlatformName)"
			ConfigurationType="4"
			UseOfMFC="0"
			CharacterSet="2"
			WholeProgramOptimization="0"
			>
			<Tool
				Name="VCPreBuildEventTool"
				CommandLine="time /t"
			/>
			<Tool
				Name="VCCustomBuildTool"
			/>
			<Tool
				Name="VCXMLDataGeneratorTool"
			/>
			<Tool
				Name="VCWebServiceProxyGeneratorTool"
			/>
			<Tool
				Name="VCMIDLTool"
				TargetEnvironment="3"
			/>
			<Tool
				Name="VCCLCompilerTool"
				Optimization="0"
				AdditionalIncludeDirectories="@MUMPS_INSTALL@\include;@MUMPS_INSTALL@\PORD\include;@MPI_INSTALL_INCLUDE@"
				PreprocessorDefinitions="WIN64;_DEBUG;_LIB;UPPER;MUMPS_CALL=;UpCase;@METIS@;@SCOTCH@;pord;NOMINMAX;@MUMPSARITH@;@SYMBOLS@"
				MinimalRebuild="false"
				BasicRuntimeChecks="0"
				SmallerTypeCheck="true"
				RuntimeLibrary="3"
				UsePrecompiledHeader="0"
				WarningLevel="2"
				Detect64BitPortabilityProblems="true"
				DebugInformationFormat="4"
			/>
			<Tool
				Name="VCManagedResourceCompilerTool"
			/>
			<Tool
				Name="VCResourceCompilerTool"
			/>
			<Tool
				Name="VCPreLinkEventTool"
				CommandLine="time /t"
			/>
			<Tool
				Name="VCLibrarianTool"
			/>
			<Tool
				Name="VCALinkTool"
			/>
			<Tool
				Name="VCXDCMakeTool"
			/>
			<Tool
				Name="VCBscMakeTool"
			/>
			<Tool
				Name="VCFxCopTool"
			/>
			<Tool
				Name="VCPostBuildEventTool"
				CommandLine="time /t"
			/>
		</Configuration>
		<Configuration
			Name="Release|Win32"
			OutputDirectory="@MUMPS_INSTALL@/lib/$(ConfigurationName)/$(PlatformName)"
			IntermediateDirectory="./do/$(ProjectName)/$(ConfigurationName)/$(PlatformName)"
			ConfigurationType="4"
			CharacterSet="2"
			WholeProgramOptimization="0"
			>
			<Tool
				Name="VCPreBuildEventTool"
				CommandLine="time /t"
			/>
			<Tool
				Name="VCCustomBuildTool"
			/>
			<Tool
				Name="VCXMLDataGeneratorTool"
			/>
			<Tool
				Name="VCWebServiceProxyGeneratorTool"
			/>
			<Tool
				Name="VCMIDLTool"
			/>
			<Tool
				Name="VCCLCompilerTool"
				Optimization="3"
				InlineFunctionExpansion="2"
				EnableIntrinsicFunctions="true"
				FavorSizeOrSpeed="1"
				OmitFramePointers="true"
				WholeProgramOptimization="false"
				AdditionalIncludeDirectories="@MUMPS_INSTALL@\include;@MUMPS_INSTALL@\PORD\include;@MPI_INSTALL_INCLUDE@"
				PreprocessorDefinitions="WIN32;NDEBUG;_LIB;UPPER;MUMPS_CALL=;UpCase;@METIS@;@SCOTCH@;pord;NOMINMAX;@MUMPSARITH@;@SYMBOLS@"
				RuntimeLibrary="2"
				StructMemberAlignment="0"
				DisableLanguageExtensions="false"
				UsePrecompiledHeader="0"
				WarningLevel="2"
				Detect64BitPortabilityProblems="true"
				DebugInformationFormat="0"
				CompileAs="1"
			/>
			<Tool
				Name="VCManagedResourceCompilerTool"
			/>
			<Tool
				Name="VCResourceCompilerTool"
			/>
			<Tool
				Name="VCPreLinkEventTool"
				CommandLine="time /t"
			/>
			<Tool
				Name="VCLibrarianTool"
			/>
			<Tool
				Name="VCALinkTool"
			/>
			<Tool
				Name="VCXDCMakeTool"
			/>
			<Tool
				Name="VCBscMakeTool"
			/>
			<Tool
				Name="VCFxCopTool"
			/>
			<Tool
				Name="VCPostBuildEventTool"
				CommandLine="time /t"
			/>
		</Configuration>
		<Configuration
			Name="Release|x64"
			OutputDirectory="@MUMPS_INSTALL@/lib/$(ConfigurationName)/$(PlatformName)"
			IntermediateDirectory="./do/$(ProjectName)/$(ConfigurationName)/$(PlatformName)"
			ConfigurationType="4"
			UseOfMFC="0"
			CharacterSet="2"
			WholeProgramOptimization="0"
			>
			<Tool
				Name="VCPreBuildEventTool"
				CommandLine="time /t"
			/>
			<Tool
				Name="VCCustomBuildTool"
			/>
			<Tool
				Name="VCXMLDataGeneratorTool"
			/>
			<Tool
				Name="VCWebServiceProxyGeneratorTool"
			/>
			<Tool
				Name="VCMIDLTool"
				TargetEnvironment="3"
			/>
			<Tool
				Name="VCCLCompilerTool"
				Optimization="3"
				InlineFunctionExpansion="2"
				EnableIntrinsicFunctions="true"
				FavorSizeOrSpeed="1"
				OmitFramePointers="true"
				AdditionalIncludeDirectories="@MUMPS_INSTALL@\include;@MUMPS_INSTALL@\PORD\include;@MPI_INSTALL_INCLUDE@"
				PreprocessorDefinitions="WIN64;NDEBUG;_LIB;UPPER;MUMPS_CALL=;UpCase;@METIS@;@SCOTCH@;pord;NOMINMAX;@MUMPSARITH@;@SYMBOLS@"
				RuntimeLibrary="2"
				StructMemberAlignment="0"
				UsePrecompiledHeader="0"
				WarningLevel="2"
				Detect64BitPortabilityProblems="true"
				DebugInformationFormat="0"
			/>
			<Tool
				Name="VCManagedResourceCompilerTool"
			/>
			<Tool
				Name="VCResourceCompilerTool"
			/>
			<Tool
				Name="VCPreLinkEventTool"
				CommandLine="time /t"
			/>
			<Tool
				Name="VCLibrarianTool"
			/>
			<Tool
				Name="VCALinkTool"
			/>
			<Tool
				Name="VCXDCMakeTool"
			/>
			<Tool
				Name="VCBscMakeTool"
			/>
			<Tool
				Name="VCFxCopTool"
			/>
			<Tool
				Name="VCPostBuildEventTool"
				CommandLine="time /t"
			/>
		</Configuration>
		<Configuration
			Name="Profile|Win32"
			OutputDirectory="@MUMPS_INSTALL@/lib/$(ConfigurationName)/$(PlatformName)"
			IntermediateDirectory="./do/$(ProjectName)/$(ConfigurationName)/$(PlatformName)"
			ConfigurationType="4"
			CharacterSet="2"
			WholeProgramOptimization="0"
			>
			<Tool
				Name="VCPreBuildEventTool"
				CommandLine="time /t"
			/>
			<Tool
				Name="VCCustomBuildTool"
			/>
			<Tool
				Name="VCXMLDataGeneratorTool"
			/>
			<Tool
				Name="VCWebServiceProxyGeneratorTool"
			/>
			<Tool
				Name="VCMIDLTool"
			/>
			<Tool
				Name="VCCLCompilerTool"
				Optimization="3"
				InlineFunctionExpansion="2"
				EnableIntrinsicFunctions="true"
				FavorSizeOrSpeed="1"
				OmitFramePointers="true"
				AdditionalIncludeDirectories="@MUMPS_INSTALL@\include;@MUMPS_INSTALL@\PORD\include;@MPI_INSTALL_INCLUDE@"
				PreprocessorDefinitions="WIN32;NDEBUG;_LIB;UPPER;MUMPS_CALL=;UpCase;@METIS@;@SCOTCH@;pord;NOMINMAX;@MUMPSARITH@;@SYMBOLS@"
				RuntimeLibrary="2"
				StructMemberAlignment="0"
				DisableLanguageExtensions="false"
				UsePrecompiledHeader="0"
				WarningLevel="2"
				Detect64BitPortabilityProblems="true"
				DebugInformationFormat="3"
				CompileAs="1"
			/>
			<Tool
				Name="VCManagedResourceCompilerTool"
			/>
			<Tool
				Name="VCResourceCompilerTool"
			/>
			<Tool
				Name="VCPreLinkEventTool"
				CommandLine="time /t"
			/>
			<Tool
				Name="VCLibrarianTool"
			/>
			<Tool
				Name="VCALinkTool"
			/>
			<Tool
				Name="VCXDCMakeTool"
			/>
			<Tool
				Name="VCBscMakeTool"
			/>
			<Tool
				Name="VCFxCopTool"
			/>
			<Tool
				Name="VCPostBuildEventTool"
				CommandLine="time /t"
			/>
		</Configuration>
		<Configuration
			Name="Profile|x64"
			OutputDirectory="@MUMPS_INSTALL@/lib/$(ConfigurationName)/$(PlatformName)"
			IntermediateDirectory="./do/$(ProjectName)/$(ConfigurationName)/$(PlatformName)"
			ConfigurationType="4"
			UseOfMFC="0"
			CharacterSet="2"
			WholeProgramOptimization="0"
			>
			<Tool
				Name="VCPreBuildEventTool"
				CommandLine="time /t"
			/>
			<Tool
				Name="VCCustomBuildTool"
			/>
			<Tool
				Name="VCXMLDataGeneratorTool"
			/>
			<Tool
				Name="VCWebServiceProxyGeneratorTool"
			/>
			<Tool
				Name="VCMIDLTool"
				TargetEnvironment="3"
			/>
			<Tool
				Name="VCCLCompilerTool"
				Optimization="3"
				InlineFunctionExpansion="2"
				EnableIntrinsicFunctions="true"
				FavorSizeOrSpeed="1"
				OmitFramePointers="true"
				AdditionalIncludeDirectories="@MUMPS_INSTALL@\include;@MUMPS_INSTALL@\PORD\include;@MPI_INSTALL_INCLUDE@"
				PreprocessorDefinitions="WIN64;NDEBUG;_LIB;UPPER;MUMPS_CALL=;UpCase;@METIS@;@SCOTCH@;pord;NOMINMAX;@MUMPSARITH@;@SYMBOLS@"
				RuntimeLibrary="2"
				StructMemberAlignment="0"
				UsePrecompiledHeader="0"
				WarningLevel="2"
				Detect64BitPortabilityProblems="true"
				DebugInformationFormat="3"
			/>
			<Tool
				Name="VCManagedResourceCompilerTool"
			/>
			<Tool
				Name="VCResourceCompilerTool"
			/>
			<Tool
				Name="VCPreLinkEventTool"
				CommandLine="time /t"
			/>
			<Tool
				Name="VCLibrarianTool"
			/>
			<Tool
				Name="VCALinkTool"
			/>
			<Tool
				Name="VCXDCMakeTool"
			/>
			<Tool
				Name="VCBscMakeTool"
			/>
			<Tool
				Name="VCFxCopTool"
			/>
			<Tool
				Name="VCPostBuildEventTool"
				CommandLine="time /t"
			/>
		</Configuration>
	</Configurations>
	<References>
	</References>
	<Files>
		<Filter
			Name="sources"
			Filter="cpp;c;cc;cxx"
			UniqueIdentifier="{@UNIQUEIDENTIFIER_SOURCES@}"
			>
		@SOURCES@
		</Filter>
		<Filter
			Name="headers"
			Filter="h;hpp;hxx"
			UniqueIdentifier="{@UNIQUEIDENTIFIER_HEADERS@}"
		>
		@HEADERS@
		</Filter>
	</Files>
	<Globals>
	</Globals>
</VisualStudioProject>
"""


msvc7_template ="""\
<?xml version="1.0" encoding="Windows-1252"?>
 <VisualStudioProject
 	ProjectType="Visual C++"
 	Version="@VERSION@"
 	Name="@NAME@"
 	ProjectGUID="{@PROJECTGUID@}"
 	RootNamespace="@NAME@_rootnamespace"
 	Keyword="Win32Proj"
 	TargetFrameworkVersion="131072"
 	>
 	<Platforms>
		<Platform Name="Win32"/>
	</Platforms>
 	<ToolFiles>
 	</ToolFiles>
 	<Configurations>
		<Configuration
 			Name="Debug|Win32"
 			OutputDirectory="@MUMPS_INSTALL@/lib/$(ConfigurationName)/$(PlatformName)"
 			IntermediateDirectory="./do/$(ProjectName)/$(ConfigurationName)/$(PlatformName)"
 			ConfigurationType="4"
 			CharacterSet="2"
 			WholeProgramOptimization="0"
 			>
 			<Tool
 				Name="VCPreBuildEventTool"
 				CommandLine="time /t"
 			/>
 			<Tool
 				Name="VCCustomBuildTool"
 			/>
 			<Tool
 				Name="VCXMLDataGeneratorTool"
 			/>
 			<Tool
 				Name="VCWebServiceProxyGeneratorTool"
 			/>
 			<Tool
 				Name="VCMIDLTool"
 			/>
 			<Tool
 				Name="VCCLCompilerTool"
 				Optimization="0"
 				AdditionalIncludeDirectories="@MUMPS_INSTALL@\include;@MUMPS_INSTALL@\PORD\include;@MPI_INSTALL_INCLUDE@"
 				PreprocessorDefinitions="WIN32;_DEBUG;_LIB;UPPER;MUMPS_CALL=;UpCase;@METIS@;@SCOTCH@;pord;NOMINMAX;@MUMPSARITH@;@SYMBOLS@"
 				MinimalRebuild="false"
 				BasicRuntimeChecks="0"
 				SmallerTypeCheck="true"
 				RuntimeLibrary="3"
 				DisableLanguageExtensions="false"
 				UsePrecompiledHeader="0"
 				WarningLevel="2"
 				Detect64BitPortabilityProblems="true"
 				DebugInformationFormat="4"
 				CompileAs="1"
 			/>
 			<Tool
 				Name="VCManagedResourceCompilerTool"
 			/>
 			<Tool
 				Name="VCResourceCompilerTool"
 			/>
 			<Tool
 				Name="VCPreLinkEventTool"
 				CommandLine="time /t"
 			/>
 			<Tool
 				Name="VCLibrarianTool"
 			/>
 			<Tool
 				Name="VCALinkTool"
 			/>
 			<Tool
 				Name="VCXDCMakeTool"
 			/>
 			<Tool
 				Name="VCBscMakeTool"
 			/>
 			<Tool
 				Name="VCFxCopTool"
 			/>
 			<Tool
 				Name="VCPostBuildEventTool"
 				CommandLine="time /t"
 			/>
 		</Configuration>
		<Configuration
 			Name="Release|Win32"
 			OutputDirectory="@MUMPS_INSTALL@/lib/$(ConfigurationName)/$(PlatformName)"
 			IntermediateDirectory="./do/$(ProjectName)/$(ConfigurationName)/$(PlatformName)"
 			ConfigurationType="4"
 			CharacterSet="2"
 			WholeProgramOptimization="0"
 			>
 			<Tool
 				Name="VCPreBuildEventTool"
 				CommandLine="time /t"
 			/>
 			<Tool
 				Name="VCCustomBuildTool"
 			/>
 			<Tool
 				Name="VCXMLDataGeneratorTool"
 			/>
 			<Tool
 				Name="VCWebServiceProxyGeneratorTool"
 			/>
 			<Tool
 				Name="VCMIDLTool"
 			/>
 			<Tool
 				Name="VCCLCompilerTool"
 				Optimization="3"
 				InlineFunctionExpansion="2"
 				EnableIntrinsicFunctions="true"
 				FavorSizeOrSpeed="1"
 				OmitFramePointers="true"
 				WholeProgramOptimization="false"
 				AdditionalIncludeDirectories="@MUMPS_INSTALL@\include;@MUMPS_INSTALL@\PORD\include;@MPI_INSTALL_INCLUDE@"
 				PreprocessorDefinitions="WIN32;NDEBUG;_LIB;UPPER;MUMPS_CALL=;UpCase;@METIS@;@SCOTCH@;pord;NOMINMAX;@MUMPSARITH@;@SYMBOLS@"
 				RuntimeLibrary="2"
 				StructMemberAlignment="0"
 				DisableLanguageExtensions="false"
 				UsePrecompiledHeader="0"
 				WarningLevel="2"
 				Detect64BitPortabilityProblems="true"
 				DebugInformationFormat="0"
 				CompileAs="1"
 			/>
 			<Tool
 				Name="VCManagedResourceCompilerTool"
 			/>
 			<Tool
 				Name="VCResourceCompilerTool"
 			/>
 			<Tool
 				Name="VCPreLinkEventTool"
 				CommandLine="time /t"
 			/>
 			<Tool
 				Name="VCLibrarianTool"
 			/>
 			<Tool
 				Name="VCALinkTool"
 			/>
 			<Tool
 				Name="VCXDCMakeTool"
 			/>
 			<Tool
 				Name="VCBscMakeTool"
 			/>
 			<Tool
 				Name="VCFxCopTool"
 			/>
 			<Tool
 				Name="VCPostBuildEventTool"
 				CommandLine="time /t"
 			/>
 		</Configuration>
		<Configuration
 			Name="Profile|Win32"
 			OutputDirectory="@MUMPS_INSTALL@/lib/$(ConfigurationName)/$(PlatformName)"
 			IntermediateDirectory="./do/$(ProjectName)/$(ConfigurationName)/$(PlatformName)"
 			ConfigurationType="4"
 			CharacterSet="2"
 			WholeProgramOptimization="0"
 			>
 			<Tool
 				Name="VCPreBuildEventTool"
 				CommandLine="time /t"
 			/>
 			<Tool
 				Name="VCCustomBuildTool"
 			/>
 			<Tool
 				Name="VCXMLDataGeneratorTool"
 			/>
 			<Tool
 				Name="VCWebServiceProxyGeneratorTool"
 			/>
 			<Tool
 				Name="VCMIDLTool"
 			/>
 			<Tool
 				Name="VCCLCompilerTool"
 				Optimization="3"
 				InlineFunctionExpansion="2"
 				EnableIntrinsicFunctions="true"
 				FavorSizeOrSpeed="1"
 				OmitFramePointers="true"
 				AdditionalIncludeDirectories="@MUMPS_INSTALL@\include;@MUMPS_INSTALL@\PORD\include;@MPI_INSTALL_INCLUDE@"
 				PreprocessorDefinitions="WIN32;NDEBUG;_LIB;UPPER;MUMPS_CALL=;UpCase;@METIS@;@SCOTCH@;pord;NOMINMAX;@MUMPSARITH@;@SYMBOLS@"
 				RuntimeLibrary="2"
 				StructMemberAlignment="0"
 				DisableLanguageExtensions="false"
 				UsePrecompiledHeader="0"
 				WarningLevel="2"
 				Detect64BitPortabilityProblems="true"
 				DebugInformationFormat="3"
 				CompileAs="1"
 			/>
 			<Tool
 				Name="VCManagedResourceCompilerTool"
 			/>
 			<Tool
 				Name="VCResourceCompilerTool"
 			/>
 			<Tool
 				Name="VCPreLinkEventTool"
 				CommandLine="time /t"
 			/>
 			<Tool
 				Name="VCLibrarianTool"
 			/>
 			<Tool
 				Name="VCALinkTool"
 			/>
 			<Tool
 				Name="VCXDCMakeTool"
 			/>
 			<Tool
 				Name="VCBscMakeTool"
 			/>
 			<Tool
 				Name="VCFxCopTool"
 			/>
 			<Tool
 				Name="VCPostBuildEventTool"
 				CommandLine="time /t"
 			/>
 		</Configuration>
	</Configurations>
 	<References>
 	</References>
 	<Files>
 		<Filter
 			Name="sources"
 			Filter="cpp;c;cc;cxx"
 			UniqueIdentifier="{@UNIQUEIDENTIFIER_SOURCES@}"
 			>
 			@SOURCES@
 		</Filter>
 		<Filter
 			Name="headers"
 			Filter="h;hpp;hxx"
 			UniqueIdentifier="{@UNIQUEIDENTIFIER_HEADERS@}"
 			>
 			@HEADERS@
 		</Filter>
 	</Files>
 	<Globals>
 	</Globals>
 </VisualStudioProject>
"""
