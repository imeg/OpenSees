import os, sys


def write_projects( mumps_install, winmumps_install, mpi_install, vs, intel, symbols, postfix, parmetis, scotch ) :
  ( mumps_headers, mumps_sources ) = ( [], [] ) # no common library in fortran
  ( smumps_headers, smumps_sources, smumps_fortran ) = ( [], [], [] )
  ( dmumps_headers, dmumps_sources, dmumps_fortran ) = ( [], [], [] )
  ( cmumps_headers, cmumps_sources, cmumps_fortran ) = ( [], [], [] )
  ( zmumps_headers, zmumps_sources, zmumps_fortran ) = ( [], [], [] )
  ( pord_headers, pord_sources, pord_fortran ) = ( [], [], [] )
  ( libseq_headers, libseq_sources, libseq_fortran ) = ( [], [], [] )
  ( example_headers, example_sources, example_fortran ) = ( [], [], [] )
  ( matlab_headers, matlab_sources, matlab_fortran ) = ( [], [], [] )
  ( scilab_headers, scilab_sources, scilab_fortran ) = ( [], [], [] )

  for dirpath, dirnames, filenames in os.walk(mumps_install) :
    for filename in filenames :
      abs_filename = os.path.join( dirpath, filename )
      ext = os.path.splitext( filename )[-1]
      has_arithmetic = False
      f = open( abs_filename, 'r' )
      if ' '.join( f.readlines() ).find( 'MUMPS_ARITH' ) >= 0 : has_arithmetic = True
      f.close()

      if os.path.basename(abs_filename) in ['ztest.F', 'hacks.c' ] : 
        continue
      elif ext in ['.h', '.hpp', '.hxx' ] : 
        if dirpath.find('PORD')>=0 : pord_headers.append( abs_filename )
        elif dirpath.find('libseq')>=0 : libseq_headers.append( abs_filename )
        elif dirpath.find('examples')>=0 : example_headers.append( abs_filename )
        elif dirpath.find('MATLAB')>=0 : matlab_headers.append( abs_filename )
        elif dirpath.find('SCILAB')>=0 : scilab_headers.append( abs_filename )
        elif has_arithmetic :
          smumps_headers.append( abs_filename )
          dmumps_headers.append( abs_filename )
          cmumps_headers.append( abs_filename )
          zmumps_headers.append( abs_filename )
        elif not filename.find( 'smumps') : smumps_headers.append( abs_filename )
        elif not filename.find( 'dmumps') : dmumps_headers.append( abs_filename )
        elif not filename.find( 'cmumps') : cmumps_headers.append( abs_filename )
        elif not filename.find( 'zmumps') : zmumps_headers.append( abs_filename )
        else : mumps_headers.append( abs_filename )
      elif ext in ['.c', '.cpp', '.cxx' ] : 
        if dirpath.find('PORD')>=0 : pord_sources.append( abs_filename )
        elif dirpath.find('libseq')>=0 : libseq_sources.append( abs_filename )
        elif dirpath.find('examples')>=0 : example_sources.append( abs_filename )
        elif dirpath.find('MATLAB')>=0 : matlab_sources.append( abs_filename )
        elif dirpath.find('SCILAB')>=0 : scilab_sources.append( abs_filename )
        elif has_arithmetic :
          smumps_sources.append( abs_filename )
          dmumps_sources.append( abs_filename )
          cmumps_sources.append( abs_filename )
          zmumps_sources.append( abs_filename )
        elif not filename.find( 'smumps') : smumps_sources.append( abs_filename )
        elif not filename.find( 'dmumps') : dmumps_sources.append( abs_filename )
        elif not filename.find( 'cmumps') : cmumps_sources.append( abs_filename )
        elif not filename.find( 'zmumps') : zmumps_sources.append( abs_filename )
        else : mumps_sources.append( abs_filename )
      elif ext in ['.f', '.f77', '.f90', '.F', '.F90' ] : 
        if dirpath.find('PORD')>=0 : pord_fortran.append( abs_filename )
        elif dirpath.find('libseq')>=0 : libseq_fortran.append( abs_filename )
        elif dirpath.find('examples')>=0 : example_fortran.append( abs_filename )
        elif dirpath.find('MATLAB')>=0 : matlab_fortran.append( abs_filename )
        elif dirpath.find('SCILAB')>=0 : scilab_fortran.append( abs_filename )
        elif not filename.find( 'smumps') : smumps_fortran.append( abs_filename )
        elif not filename.find( 'dmumps') : dmumps_fortran.append( abs_filename )
        elif not filename.find( 'cmumps') : cmumps_fortran.append( abs_filename )
        elif not filename.find( 'zmumps') : zmumps_fortran.append( abs_filename )
        else : 
          smumps_fortran.append( abs_filename )
          dmumps_fortran.append( abs_filename )
          cmumps_fortran.append( abs_filename )
          zmumps_fortran.append( abs_filename )
      else :
        pass # print abs_filename

  from templates import write_c_project
  if  mumps_sources : write_c_project( vs, 'mumps_common_c'+postfix, None, mumps_headers, mumps_sources, symbols, mumps_install, winmumps_install, mpi_install, parmetis, scotch ) 
  if smumps_sources : write_c_project( vs, 'smumps_c'+postfix, 's', smumps_headers, smumps_sources, symbols, mumps_install, winmumps_install, mpi_install, parmetis, scotch ) 
  if dmumps_sources : write_c_project( vs, 'dmumps_c'+postfix, 'd', dmumps_headers, dmumps_sources, symbols, mumps_install, winmumps_install, mpi_install, parmetis, scotch ) 
  if cmumps_sources : write_c_project( vs, 'cmumps_c'+postfix, 'c', cmumps_headers, cmumps_sources, symbols, mumps_install, winmumps_install, mpi_install, parmetis, scotch ) 
  if zmumps_sources : write_c_project( vs, 'zmumps_c'+postfix, 'z', zmumps_headers, zmumps_sources, symbols, mumps_install, winmumps_install, mpi_install, parmetis, scotch ) 
  if libseq_sources : write_c_project( vs, 'libseq_c'+postfix, None, libseq_headers, libseq_sources, symbols, mumps_install, winmumps_install, mpi_install, parmetis, scotch ) 
  if pord_sources   : write_c_project( vs, 'pord_c'+postfix, None, pord_headers, pord_sources, symbols, mumps_install, winmumps_install, mpi_install, parmetis, scotch ) 

  from templates import write_fortran_project
  if smumps_fortran : write_fortran_project( intel, 'smumps_fortran'+postfix, 's', smumps_fortran, symbols, mumps_install, winmumps_install, mpi_install, parmetis, scotch ) 
  if dmumps_fortran : write_fortran_project( intel, 'dmumps_fortran'+postfix, 'd', dmumps_fortran, symbols, mumps_install, winmumps_install, mpi_install, parmetis, scotch ) 
  if cmumps_fortran : write_fortran_project( intel, 'cmumps_fortran'+postfix, 'c', cmumps_fortran, symbols, mumps_install, winmumps_install, mpi_install, parmetis, scotch ) 
  if zmumps_fortran : write_fortran_project( intel, 'zmumps_fortran'+postfix, 'z', zmumps_fortran, symbols, mumps_install, winmumps_install, mpi_install, parmetis, scotch ) 
  if libseq_fortran : write_fortran_project( intel, 'libseq_fortran'+postfix, None, libseq_fortran, symbols, mumps_install, winmumps_install, mpi_install, parmetis, scotch ) 
  if pord_fortran   : write_fortran_project( intel, 'pord_fortran'+postfix, None, pord_fortran, symbols, mumps_install, winmumps_install, mpi_install, parmetis, scotch ) 


#
# main 
#

from optparse import OptionParser
option_parser = OptionParser()
option_parser.add_option( "-o" ,"--winmumpsdir"  ,dest="winmumpsdir" ,default=None , type=str   ,		         help="Specify the directory where the project files will be written (can be overloaded by setting the env. var. WINMUMPS_INSTALL)" )
option_parser.add_option( "-u" ,"--mumpsdir"     ,dest="mumpsdir"    ,default=None , type=str   ,		         help="Specify the directory containing MUMPS (can be overloaded by setting the env. var. MUMPS_INSTALL)" )
option_parser.add_option( "-v" ,"--msvc"         ,dest="msvc"        ,default=10,    type=int   ,		         help="Specify the version of msvc (8 and 10 are suppported)" )
option_parser.add_option( "-i" ,"--intelfortran" ,dest="intel"       ,default=11.0,  type=float ,		         help="Specify the version of Intel Fortran Compiler" )
option_parser.add_option( "-p" ,"--mpidir"       ,dest="mpidir"      ,default=None , type=str   ,		         help="Specify the directory where the MPI librarie is installed" )
option_parser.add_option( "-s" ,"--symbols"      ,dest="symbols"     ,default=None , type=str   ,		         help="Add preprocessor symbols" )
option_parser.add_option( "-t" ,"--postfix"      ,dest="postfix"     ,default=''   , type=str   ,		         help="Add a postfix to the name of the project files" )
option_parser.add_option( "-m" ,"--parmetis"     ,dest="parmetis"    ,default=False, action='store_true',    help="Build with parmetis" )
option_parser.add_option( "-c" ,"--scotch"       ,dest="scotch"      ,default=False, action='store_true',     help="Build with scotch" )
(options,args) = option_parser.parse_args(sys.argv[1:])

if not options.winmumpsdir :
  options.winmumpsdir = os.getenv( 'WINMUMPS_INSTALL' )
  if not options.winmumpsdir : options.winmumpsdir = os.getcwd()
options.winmumpsdir = os.path.abspath( options.winmumpsdir )
if not os.path.isdir( options.winmumpsdir ) : sys.exit( "'"+options.winmumpsdir+"' invalid directory" )

if not options.mumpsdir :
  options.mumpsdir = os.getenv( 'MUMPS_INSTALL' )
  if not options.mumpsdir : options.mumpsdir = os.getcwd()
options.mumpsdir = os.path.abspath( options.mumpsdir )
if not os.path.isdir( options.mumpsdir ) : sys.exit( "'"+options.mumpsdir+"' invalid directory" )

if not options.mpidir :
  options.mpidir = os.path.join( options.mumpsdir, 'libseq' )
  print '[caution] libseq is used as the MPI library'
options.mpidir = os.path.abspath( options.mpidir )
if not os.path.isdir( options.mpidir ) : sys.exit( "'"+options.mpidir+"' invalid directory" )

if not options.msvc: sys.exit( "The version of Visual Studio must be specified on the command line" )
if not options.intel : sys.exit( "The version of Intel Fortran Compiler must be specified on the command line" )
if options.msvc<8 or options.msvc>10 : sys.exit( "Visual Studio " + str(options.msvc) + " is not supported" )

write_projects( options.mumpsdir, options.winmumpsdir, options.mpidir, options.msvc, options.intel, options.symbols, options.postfix, options.parmetis, options.scotch )

